package com.dbms.model;

public class Employee {

	private int employeeid;
	private String employeename;
	private String employeephone;
	private String employeesalary;
	private String employeepassword;
	
	
	public String getEmployeepassword() {
		return employeepassword;
	}
	public void setEmployeepassword(String employeepassword) {
		this.employeepassword = employeepassword;
	}
	public String getEmployeesalary() {
		return employeesalary;
	}
	public void setEmployeesalary(String employeesalary) {
		this.employeesalary = employeesalary;
	}
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public String getEmployeephone() {
		return employeephone;
	}
	public void setEmployeephone(String employeephone) {
		this.employeephone = employeephone;
	}
	  
}
