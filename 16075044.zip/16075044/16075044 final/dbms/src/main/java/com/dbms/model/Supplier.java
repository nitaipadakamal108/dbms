package com.dbms.model;

public class Supplier {

	private int supplierid;
	private String suppliername;
	private String supplierphone;
	private String supplieraddress;
	
	public int getSupplierid() {
		return supplierid;
	}
	public void setSupplierid(int supplierid) {
		this.supplierid = supplierid;
	}
	public String getSuppliername() {
		return suppliername;
	}
	public void setSuppliername(String suppliername) {
		this.suppliername = suppliername;
	}
	public String getSupplierphone() {
		return supplierphone;
	}
	public void setSupplierphone(String supplierphone) {
		this.supplierphone = supplierphone;
	}
	public String getSupplieraddress() {
		return supplieraddress;
	}
	public void setSupplieraddress(String supplieraddress) {
		this.supplieraddress = supplieraddress;
	}
}
