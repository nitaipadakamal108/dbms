-- MySQL dump 10.13  Distrib 8.0.3-rc, for Linux (x86_64)
--
-- Host: localhost    Database: spring
-- ------------------------------------------------------
-- Server version	8.0.3-rc-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CART`
--

DROP TABLE IF EXISTS `CART`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `CART` (
  `username` varchar(20) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`username`,`productid`),
  KEY `productid` (`productid`),
  CONSTRAINT `CART_ibfk_1` FOREIGN KEY (`username`) REFERENCES `USERS` (`username`),
  CONSTRAINT `CART_ibfk_2` FOREIGN KEY (`productid`) REFERENCES `PRODUCTS` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CART`
--

LOCK TABLES `CART` WRITE;
/*!40000 ALTER TABLE `CART` DISABLE KEYS */;
INSERT INTO `CART` VALUES ('lovish',1,1),('sahaj',2,1),('sankalp',3,1),('avil',4,1),('piyush',5,1);
/*!40000 ALTER TABLE `CART` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CATEGORIES`
--

DROP TABLE IF EXISTS `CATEGORIES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `CATEGORIES` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(45) NOT NULL,
  `categorydescription` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CATEGORIES`
--

LOCK TABLES `CATEGORIES` WRITE;
/*!40000 ALTER TABLE `CATEGORIES` DISABLE KEYS */;
INSERT INTO `CATEGORIES` VALUES (1,'Income Tax Consultancy','for consulting regarding the pay of income tax by your company'),(2,'GST Consultancy','Regarding the new GST Rules'),(3,'Accounting','to maintain the accounts of your company'),(4,'Auditing','For bank audits');
/*!40000 ALTER TABLE `CATEGORIES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUSTOMERS`
--

DROP TABLE IF EXISTS `CUSTOMERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `CUSTOMERS` (
  `username` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(50) DEFAULT NULL,
  `pin` int(11) NOT NULL,
  `city` varchar(20) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `mail` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUSTOMERS`
--

LOCK TABLES `CUSTOMERS` WRITE;
/*!40000 ALTER TABLE `CUSTOMERS` DISABLE KEYS */;
INSERT INTO `CUSTOMERS` VALUES ('Shivsun marbles','Aditya','Makrana Chauraha',225,'Makrana','9214','shivsun@gmail.com'),('Jain Industries','Saaket','Near Govind Dev Temple',229,'Jaipur','9215','jain@gmail.com'),('agarwal granites','Sunil','Near Maingate',235,'Kishangarh','9216','agarwal@gmail.com'),('rkmarble','ashok','Near Lake',240,'Udaipur','9217','rk@gmail.com'),('siddshoppe','Siddharth','gaa',500094,'Var','31','sid@gmail.com'),('tejas','Tejas','Tejas',221005,'Hyderabad','Store','tejas@gmail.com');
/*!40000 ALTER TABLE `CUSTOMERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMPLOYEES`
--

DROP TABLE IF EXISTS `EMPLOYEES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `EMPLOYEES` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `employeename` varchar(45) DEFAULT NULL,
  `employeephone` varchar(10) DEFAULT NULL,
  `employeesalary` double DEFAULT NULL,
  `employeepassword` varchar(20) DEFAULT '',
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMPLOYEES`
--

LOCK TABLES `EMPLOYEES` WRITE;
/*!40000 ALTER TABLE `EMPLOYEES` DISABLE KEYS */;
INSERT INTO `EMPLOYEES` VALUES (1,'ramjilal','9310',30000,'123'),(2,'raj','9315',45000,'456');
/*!40000 ALTER TABLE `EMPLOYEES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FEEDBACKS`
--

DROP TABLE IF EXISTS `FEEDBACKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `FEEDBACKS` (
  `feedbackid` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) DEFAULT NULL,
  `feedback` varchar(200) DEFAULT NULL,
  `feedbackdate` date DEFAULT NULL,
  `feedbacktime` time DEFAULT NULL,
  `feedbackusername` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`feedbackid`),
  KEY `fk_F_U` (`orderid`),
  KEY `fk_FE_U` (`feedbackusername`),
  CONSTRAINT `fk_FE_U` FOREIGN KEY (`feedbackusername`) REFERENCES `USERS` (`username`),
  CONSTRAINT `fk_F_U` FOREIGN KEY (`orderid`) REFERENCES `USERORDERS` (`orderid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FEEDBACKS`
--

LOCK TABLES `FEEDBACKS` WRITE;
/*!40000 ALTER TABLE `FEEDBACKS` DISABLE KEYS */;
INSERT INTO `FEEDBACKS` VALUES (1,1,'hello',NULL,NULL,'shiv'),(2,10,'Very bad','2018-09-26','00:13:35','ashok'),(3,10,'abc','2018-09-26','00:57:40','raju'),(4,10,'abc','2018-09-26','00:57:45','gehlot'),(8,11,'late','2018-018-09-27','17:26:07','gamma'),(26,7,'dfd','2018-09-30','01:51:19','gamma'),(27,7,'very bad','2018-09-30','01:57:22','gamma'),(28,18,'bye','2018-09-30','02:54:57','root');
/*!40000 ALTER TABLE `FEEDBACKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LIKES`
--

DROP TABLE IF EXISTS `LIKES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `LIKES` (
  `username` varchar(20) NOT NULL,
  `productid` int(11) NOT NULL,
  PRIMARY KEY (`username`,`productid`),
  KEY `fk_L_P` (`productid`),
  CONSTRAINT `fk_L_P` FOREIGN KEY (`productid`) REFERENCES `PRODUCTS` (`productid`),
  CONSTRAINT `fk_L_U` FOREIGN KEY (`username`) REFERENCES `USERS` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LIKES`
--

LOCK TABLES `LIKES` WRITE;
/*!40000 ALTER TABLE `LIKES` DISABLE KEYS */;
INSERT INTO `LIKES` VALUES ('Accounts',1),('GST Consultancy',2),('Auditing',4),('Accounts',7),('GST Consultancy',7),('Income tax consultancy',11),('accounts',14),('Auditing',15);
/*!40000 ALTER TABLE `LIKES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NOTIFICATIONS`
--

DROP TABLE IF EXISTS `NOTIFICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `NOTIFICATIONS` (
  `notificationid` int(11) NOT NULL AUTO_INCREMENT,
  `notification` varchar(200) DEFAULT NULL,
  `notificationdate` date DEFAULT NULL,
  `notificationtime` time DEFAULT NULL,
  PRIMARY KEY (`notificationid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NOTIFICATIONS`
--

LOCK TABLES `NOTIFICATIONS` WRITE;
/*!40000 ALTER TABLE `NOTIFICATIONS` DISABLE KEYS */;
INSERT INTO `NOTIFICATIONS` VALUES (1,'new GST Rules byy GoI','2019-10-13','00:16:35'),(2,'New Income Tax return filing dates','2019-10-12','01:36:49'),(4,'Annual Indian Budget','2019-10-11','02:41:21');
/*!40000 ALTER TABLE `NOTIFICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDERPRODUCTS`
--

DROP TABLE IF EXISTS `ORDERPRODUCTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `ORDERPRODUCTS` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `productid` int(11) NOT NULL,
  `orderquantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderid`,`productid`),
  KEY `FK_OP_P` (`productid`),
  CONSTRAINT `FK_OP_P` FOREIGN KEY (`productid`) REFERENCES `PRODUCTS` (`productid`),
  CONSTRAINT `fk_OP_UO` FOREIGN KEY (`orderid`) REFERENCES `USERORDERS` (`orderid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDERPRODUCTS`
--

LOCK TABLES `ORDERPRODUCTS` WRITE;
/*!40000 ALTER TABLE `ORDERPRODUCTS` DISABLE KEYS */;
INSERT INTO `ORDERPRODUCTS` VALUES (1,1,2),(1,4,5),(2,1,1),(2,2,1),(2,6,1),(2,9,1),(2,11,2),(3,6,1),(3,9,1),(3,11,1),(4,2,2),(4,3,3),(4,9,2),(5,2,2),(5,3,3),(5,9,2),(6,2,2),(6,3,3),(6,9,2),(7,2,2),(7,3,3),(7,9,2),(8,2,2),(8,3,3),(8,9,2),(9,2,2),(9,3,1),(9,9,1),(10,1,1),(10,10,1),(10,12,1),(11,10,1),(12,2,1),(12,3,3),(12,7,1),(12,14,1),(14,2,1),(15,14,7),(16,1,4),(16,2,6),(17,1,1),(17,2,1),(18,12,1);
/*!40000 ALTER TABLE `ORDERPRODUCTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCTS`
--

DROP TABLE IF EXISTS `PRODUCTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `PRODUCTS` (
  `productid` int(11) NOT NULL AUTO_INCREMENT,
  `productname` varchar(45) DEFAULT NULL,
  `productprice` double DEFAULT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `availablequantity` int(11) DEFAULT '0',
  `description` varchar(150) DEFAULT '',
  PRIMARY KEY (`productid`),
  KEY `categoryid` (`categoryid`),
  CONSTRAINT `PRODUCTS_ibfk_1` FOREIGN KEY (`categoryid`) REFERENCES `CATEGORIES` (`categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCTS`
--

LOCK TABLES `PRODUCTS` WRITE;
/*!40000 ALTER TABLE `PRODUCTS` DISABLE KEYS */;
INSERT INTO `PRODUCTS` VALUES (1,'Bank Annual earning',500,4,1,'Annual bank auditing by latest software'),(2,'GST Debate Discussion',1000,2,1,'High level GST Discussions');
/*!40000 ALTER TABLE `PRODUCTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SUPPLIERPRODUCTS`
--

DROP TABLE IF EXISTS `SUPPLIERPRODUCTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `SUPPLIERPRODUCTS` (
  `supplierid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  PRIMARY KEY (`supplierid`,`productid`),
  CONSTRAINT `fk_SP_P` FOREIGN KEY (`supplierid`) REFERENCES `PRODUCTS` (`productid`),
  CONSTRAINT `fk_SP_S` FOREIGN KEY (`supplierid`) REFERENCES `SUPPLIERS` (`supplierid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SUPPLIERPRODUCTS`
--

LOCK TABLES `SUPPLIERPRODUCTS` WRITE;
/*!40000 ALTER TABLE `SUPPLIERPRODUCTS` DISABLE KEYS */;
INSERT INTO `SUPPLIERPRODUCTS` VALUES (1,1),(3,1);
/*!40000 ALTER TABLE `SUPPLIERPRODUCTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SUPPLIERS`
--

DROP TABLE IF EXISTS `SUPPLIERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `SUPPLIERS` (
  `supplierid` int(11) NOT NULL AUTO_INCREMENT,
  `suppliername` varchar(20) DEFAULT NULL,
  `supplierphone` varchar(10) DEFAULT NULL,
  `supplieraddress` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`supplierid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SUPPLIERS`
--

LOCK TABLES `SUPPLIERS` WRITE;
/*!40000 ALTER TABLE `SUPPLIERS` DISABLE KEYS */;
INSERT INTO `SUPPLIERS` VALUES (1,'Dhanraj Electrician','2345567788','Bijaynagar'),(2,'Ramu Gardener','123','123'),(3,'Nawaz Paani Wala','1234','1234');
/*!40000 ALTER TABLE `SUPPLIERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERORDERS`
--

DROP TABLE IF EXISTS `USERORDERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `USERORDERS` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `orderdate` date DEFAULT NULL,
  `ordertime` time DEFAULT NULL,
  `employeeid` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderid`),
  KEY `FK_UO_U` (`username`),
  KEY `fk_UO_E` (`employeeid`),
  CONSTRAINT `FK_UO_U` FOREIGN KEY (`username`) REFERENCES `USERS` (`username`),
  CONSTRAINT `fk_UO_E` FOREIGN KEY (`employeeid`) REFERENCES `EMPLOYEES` (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERORDERS`
--

LOCK TABLES `USERORDERS` WRITE;
/*!40000 ALTER TABLE `USERORDERS` DISABLE KEYS */;
INSERT INTO `USERORDERS` VALUES (1,'tejas',500,'Assigned','2018-09-24',NULL,1),(2,'ashok',1165,'Completed',NULL,'23:21:13',1),(3,'completed',525,'Cancelled',NULL,NULL,1),(4,'Tejas',250,'Cancelled',NULL,NULL,1),(5,'Mukesh',250,'Cancelled',NULL,NULL,1);
/*!40000 ALTER TABLE `USERORDERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERS`
--

DROP TABLE IF EXISTS `USERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `USERS` (
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `enabled` int(11) DEFAULT '1',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERS`
--

LOCK TABLES `USERS` WRITE;
/*!40000 ALTER TABLE `USERS` DISABLE KEYS */;
INSERT INTO `USERS` VALUES ('Tejas','Tejas',1),('Mukesh','Mukesh',1),('Ashok','Ashok',1),('Aditya','Aditya',1),('Kanchan','Kanchan',1),('Aman','Aman',1),('Bhima','Bhima',1),('Arjuna','Arjuna',1),('Yudhus','Yushus',1),('Naseer','Naseer',1),('root','root',1),('Abdul','Abdul',1);
/*!40000 ALTER TABLE `USERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERS_ROLES`
--

DROP TABLE IF EXISTS `USERS_ROLES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `USERS_ROLES` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`role_id`),
  KEY `user` (`user`),
  CONSTRAINT `USERS_ROLES_ibfk_1` FOREIGN KEY (`user`) REFERENCES `USERS` (`username`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USERS_ROLES`
--

LOCK TABLES `USERS_ROLES` WRITE;
/*!40000 ALTER TABLE `USERS_ROLES` DISABLE KEYS */;
INSERT INTO `USERS_ROLES` VALUES (1,'root','ROLE_ADMIN'),(2,'Mukesh','ROLE_USER'),(3,'Tejas','ROLE_USER'),(4,'Ashok','ROLE_USER'),(5,'Aditya','ROLE_USER'),(6,'Ramjilal','ROLE_EMPLOYEE'),(8,'Aman','ROLE_USER'),(9,'Naseer','ROLE_USER'),(10,'Abdul','ROLE_USER'),(11,'Yudhus','ROLE_USER'),(13,'Root','ROLE_USER'),(12,'raj','ROLE_EMPLOYEE'),(15,'Kanchan','ROLE_USER');
/*!40000 ALTER TABLE `USERS_ROLES` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-30  3:40:29
