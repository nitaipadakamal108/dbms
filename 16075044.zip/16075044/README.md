# springmvc
Spring Mvc Project for Database course
Using JDBC, Maven, MySQL and Java
